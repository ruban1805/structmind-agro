---
name: Agro-Intelligence Terminal
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  grid-gutter: 1rem
  grid-margin: 1.5rem
  panel-padding: 1rem
  compact-gap: 0.5rem
  micro-gap: 0.25rem
  section-gap: 2rem
---

## Brand & Style

This design system establishes an ultra-precise, high-density decision cockpit engineered for precision agriculture, autonomous agronomic intelligence, and spatial bio-telemetry. Designed to bridge tactical field ops with predictive AI analytics, the visual language departs from consumer farm apps in favor of an authoritative "Agronomic Mission Control" aesthetic.

### Aesthetic Axioms
- **Futuristic GIS & Bio-Cybernetics:** Interfaces evoke aerospace telemetry terminals calibrated for living soil, crop phenotyping, and micro-climate modeling. 
- **Analytical High Density:** Space is utilized deliberately to present complex multi-spectral scans, localized sensor clusters, and predictive yields without visual clutter.
- **Luminescent Signal-to-Noise Ratio:** Ambient dark slate architecture acts as an absorbing substrate, allowing phosphor bioluminescent greens, cyan radar markers, and amber drought/pest vectors to instantly communicate critical variance.
- **Utilitarian Elegance:** Technical borders, micro-grids, and monospaced telemetry tickers deliver immediate institutional trust suitable for both enterprise agro-conglomerates and high-impact hackathon/SIH demonstrations.

## Colors

The palette operates under a high-contrast dark-mode regime where deep geological charcoal and obsidian tones contrast with sharp, luminescent spectral accents.

### Palette Roles & Specifications
- **Base Canvas & Slate Substrates:**
  - `canvas-deep`: `#050B0E` (Primary dark background absorbing atmospheric glare)
  - `surface-base`: `#0B131B` (Structural panel background)
  - `surface-elevated`: `#111E2A` (Floating telemetry cards, overlays, drawer menus)
  - `surface-border`: `#1E2E3D` (Crisp structural outlines and grid lines)
- **Signal & Telemetry Primaries:**
  - `primary` (`#10B981` / Luminescent Bio-Green): Optimal canopy indices, healthy NDVI biomass markers, confirmed system recommendations, and prime telemetry metrics.
  - `secondary` (`#06B6D4` / Spectral Cyan): Hydrological levels, atmospheric water vapor, LiDAR/GIS vector paths, autonomous drone trajectories.
  - `tertiary` (`#F59E0B` / Amber Warning): Evapotranspiration alerts, nitrogen deficit, pest detection thresholds, and volatile weather warnings.
- **Critical Diagnostics:**
  - `alert-critical` (`#EF4444`): Extreme crop stress, irrigation valve failure, pathogen outbreak.
  - `neutral-foreground` (`#E2E8F0`): Primary high-legibility alphanumeric data.
  - `neutral-muted` (`#64748B`): Coordinate axes, column headers, secondary radar annotations.

## Typography

The typographic hierarchy separates structural headlines, narrative context, and continuous data streams into dedicated roles:

- **Space Grotesk (Headers & Hero Display):** Carries angular, geometric technical authority reminiscent of modern aerospace engineering. Applied to platform overview titles, sector names, and major modal dialogs.
- **Inter (Body & Operational Interfaces):** Neutral, hyper-legible neo-grotesque foundation engineered for quick scanning across dense forms, decision trees, and agronomic diagnostic explanations.
- **JetBrains Mono (Telemetry, Coordinates & Data Labels):** Applied universally to sensor values, coordinates (latitude/longitude), NDVI values, timestamps, and compact telemetry tickers. Ensures zero tabular shifting when metrics cycle live.

## Layout & Spacing

The layout is built upon a high-density, viewport-optimized modular canvas. Agricultural operations require persistent spatial awareness; therefore, the default configuration prioritizes split-panel or dashboard topologies over deep linear scrolling.

### Layout Mechanics
- **GIS Canvas & Analytical Docking:** In primary desktop viewports (`>= 1280px`), the platform anchors a dynamic 60/40 or 70/30 split: a responsive full-height GIS spatial map paired with an analytical telemetry dock.
- **12-Column Responsive Grid:** Nested cards and metric modules adhere to a 12-column sub-grid with standard 16px (`1rem`) gutters and strict 24px (`1.5rem`) viewport outer margins.
- **Modular Reflow:**
  - **Desktop (`>= 1024px`):** Multi-column telemetry grids, multi-layer GIS sidebars, synchronized time-series rows.
  - **Tablet (`768px - 1023px`):** Telemetry docks collapse into bottom drawers or slide-over overlays over the spatial map.
  - **Mobile (`< 768px`):** Stacked single-column hierarchy; map converts to a dedicated toggle view, prioritized telemetry summaries stack vertically using 8px (`0.5rem`) component spacing.

## Elevation & Depth

This design system achieves physical depth without heavy, diffuse drop shadows that degrade data contrast. Depth is established through **tonal stratification**, **back-illuminated glass planes**, and **precision hairline contours**.

### Depth Layers
- **Substrate Level 0 (Ground Canvas):** `#050B0E` static void background or underlying Mapbox/GIS terrain tiles.
- **Substrate Level 1 (Base Panels):** Solid `#0B131B` with a 1px continuous border of `#1E2E3D`.
- **Substrate Level 2 (HUD Overlays & Cards):** Glassmorphic `#111E2A` at 85% opacity paired with `backdrop-filter: blur(12px)` and a directional 1px perimeter highlight (`rgba(255, 255, 255, 0.08)` along top edges).
- **Substrate Level 3 (Context Modals & Tactical Popovers):** Solid `#152433` accompanied by a localized ambient glow: `0 8px 32px -4px rgba(0, 0, 0, 0.65)`, complemented by a 1px border colored with subtle primary/secondary radiance (`rgba(16, 185, 129, 0.2)`).

## Shapes

The design system employs a **Soft Technical (`1`)** shape language:
- Core UI elements utilize disciplined `4px` (`0.25rem`) radii, while macro telemetry panels and modal containers scale up to `8px` (`0.5rem`).
- Radii are purposefully restrained to evoke military-spec avionics and laboratory telemetry instrumentation. Circular pills are restricted solely to live status badges and drone ping indicators.

## Components

### Buttons & Operational Triggers
- **Primary Bio-Action (Action Engine):** Solid emerald (`#10B981`) fill with dark obsidian text (`#050B0E`), font `Space Grotesk` weight 600. On hover: intense perimeter aura (`0 0 16px rgba(16, 185, 129, 0.45)`).
- **Secondary Telemetry Trigger:** Dark slate base (`#111E2A`), 1px cyan border (`#06B6D4`), text `#06B6D4`. Hover engages a subtle cyan tint wash (`rgba(6, 182, 212, 0.1)`).
- **Destructive/Emergency Stop:** Amber-to-red border (`#EF4444`), text `#EF4444`, dark crimson glass background.

### Telemetry Cards & Metric Tickers
- Structured with an upper sub-header containing uppercase `label-caps` in `#64748B`, an integrated status micro-LED (green/cyan/amber), and a primary numerical payload rendered in `JetBrains Mono` (`telemetry-lg`).
- Micro sparklines or deviation bands (`+3.4% VWC`) sit at the base, separated by a 1px border (`#1E2E3D`).

### Status Badges & Agronomic Chips
- Compact, flat, non-intrusive metadata capsules.
- Rendered with `rgba()` background variations of the status color at 12% opacity, a 1px solid border at 30% opacity, and sharp `JetBrains Mono` typography.
- **Examples:** `[● NDVI 0.82 OPTIMAL]`, `[▲ SOIL MOISTURE DEFICIT]`.

### Form Fields & Spatial Parameter Inputs
- Dark inputs (`#080E14`) inset within panels, bordered with 1px `#1E2E3D`.
- Focus shifts border to `#06B6D4` with a subtle inside glow (`box-shadow: inset 0 0 4px rgba(6, 182, 212, 0.2)`).
- Prefix and suffix units (e.g., `pH`, `m³/h`, `hPa`) formatted in muted monospace.

### GIS Tactical Overlays & Timeline Sliders
- Floating HUD toolbars stacked over map views with semi-translucent slate backgrounds (`backdrop-filter: blur(16px)`).
- Step-scrubbers and temporal playback controls feature luminescent scrub-heads with continuous coordinate and timestamp readouts (`UTC 2025-04-12 04:30:00`).